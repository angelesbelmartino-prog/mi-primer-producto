# Ruta de Vocabulario

App gamificada de práctica de vocabulario. Frontend en HTML + React (vía CDN,
sin build), con una función serverless en `/api/generate` que llama a la
API de Claude para generar las tarjetas.

## Estructura

```
index.html          → toda la app (UI, lógica, estilos)
api/generate.js      → función serverless (Vercel) que llama a Anthropic
                        usando tu API key guardada en el servidor
package.json
.env.example
```

## 1. Subir a GitHub

```bash
git init
git add .
git commit -m "Ruta de Vocabulario"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/ruta-de-vocabulario.git
git push -u origin main
```

## 2. Desplegar en Vercel

1. Entrá a [vercel.com](https://vercel.com) → **Add New → Project**.
2. Importá el repo de GitHub que acabás de crear.
3. Framework Preset: dejalo en **Other** (no hace falta build, es HTML estático + funciones).
4. Antes de dar a "Deploy", andá a **Environment Variables** y agregá:
   - `ANTHROPIC_API_KEY` = tu API key de [console.anthropic.com](https://console.anthropic.com)
5. Deploy. Listo — Vercel sirve `index.html` como estático y `api/generate.js`
   como función serverless automáticamente, sin configuración extra.

## 3. Probar en local (opcional)

```bash
npm i -g vercel
cp .env.example .env.local   # y completá tu API key real
vercel dev
```

## Notas importantes

- **Nunca** pongas tu API key directamente en `index.html` ni en el repo:
  quedaría expuesta públicamente a cualquiera que abra el código fuente de
  la página. Por eso existe `api/generate.js`: la key vive solo en el
  servidor (variable de entorno de Vercel).
- El progreso (racha, puntos, palabras dominadas, historial) se guarda con
  `localStorage` en el navegador de cada persona — es local a su dispositivo,
  no se sincroniza entre navegadores ni dispositivos.
- El modelo usado en `api/generate.js` es `claude-sonnet-5`. Verificá en tu
  consola de Anthropic que tengas acceso a ese modelo, o cambiá el valor de
  `model` por el que corresponda a tu cuenta.
- Como no hay paso de build (React + Babel se cargan por CDN y el JSX se
  transpila en el navegador), el proyecto es simple de mantener, pero carga
  algo más lento que una app compilada. Es más que suficiente para esta
  herramienta; si más adelante querés migrarla a Vite/Next.js, la lógica de
  `index.html` se puede mover a componentes tal cual.
