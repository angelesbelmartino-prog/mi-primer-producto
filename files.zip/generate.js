// api/generate.js
// Función serverless de Vercel: recibe { prompt } desde el frontend y llama
// a la API de Anthropic usando la API key guardada como variable de entorno
// en el servidor (nunca expuesta al navegador del usuario).

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Método no permitido" });
    return;
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    res.status(500).json({
      error: "Falta configurar la variable de entorno ANTHROPIC_API_KEY en Vercel.",
    });
    return;
  }

  const { prompt } = req.body || {};
  if (!prompt || typeof prompt !== "string") {
    res.status(400).json({ error: "Falta 'prompt' en el body de la petición." });
    return;
  }

  try {
    const anthropicResponse = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        // Verifica en tu consola de Anthropic (console.anthropic.com) cuál es
        // el modelo vigente al que tenés acceso; "claude-sonnet-5" es el
        // recomendado como buen balance de calidad/costo al momento de escribir esto.
        model: "claude-sonnet-5",
        max_tokens: 1000,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    const data = await anthropicResponse.json();

    if (!anthropicResponse.ok) {
      res.status(anthropicResponse.status).json({ error: data });
      return;
    }

    // Devolvemos la respuesta de Anthropic tal cual: el frontend ya sabe
    // leer data.content (array de bloques {type, text}).
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: "Error al contactar la API de Anthropic." });
  }
}
